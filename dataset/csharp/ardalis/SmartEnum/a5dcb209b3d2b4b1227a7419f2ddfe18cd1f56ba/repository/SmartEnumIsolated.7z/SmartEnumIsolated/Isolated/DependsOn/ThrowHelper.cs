namespace SmartEnumIsolated.Isolated.DependsOn
{
    static class ThrowHelper
    {
        public static void ThrowArgumentNullOrEmptyException(string paramName)
            => throw new ArgumentException("Argument cannot be null or empty.", paramName);

        public static void ThrowValueNotFoundException<TEnum, TValue>(TValue value)
            where TEnum : ISmartEnum
            where TValue : IEquatable<TValue>, IComparable<TValue>
            => throw new SmartEnumNotFoundException($"No {typeof(TEnum).Name} with Value {value} found.");
    }
}