namespace SmartEnumIsolated.Isolated.DependsOn
{
    /// <summary>
    /// 
    /// </summary>
    public interface ISmartEnum
    {
        // Empty Interface
    }
}