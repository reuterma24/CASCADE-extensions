﻿using ImageSharp;

namespace ImageSharpIsolated.Tests
{
    public class PngDecoderTests
    {
        [Fact]
        public void Test1()
        {
            var decoder = new PngDecoder();
            decoder.ReadHeaderChunk([]);
        }
    }
}