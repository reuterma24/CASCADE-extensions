﻿using System.Buffers.Binary;
using ImageSharp.DependsOn;

namespace ImageSharp;

public class PngDecoder
{
    private PngHeader header;

    /// <summary>
    /// Reads a header chunk from the data.
    /// </summary>
    /// <param name="data">The <see cref="T:ReadOnlySpan{byte}"/> containing data.</param>
    public void ReadHeaderChunk(ReadOnlySpan<byte> data)
    {
        this.header = new PngHeader
        {
            Width = BinaryPrimitives.ReadInt32BigEndian(data.Slice(0, 4)),
            Height = BinaryPrimitives.ReadInt32BigEndian(data.Slice(4, 4)),
            BitDepth = data[8],
            ColorType = (PngColorType)data[9],
            CompressionMethod = data[10],
            FilterMethod = data[11],
            InterlaceMethod = (PngInterlaceMode)data[12]
        };
    }
}
