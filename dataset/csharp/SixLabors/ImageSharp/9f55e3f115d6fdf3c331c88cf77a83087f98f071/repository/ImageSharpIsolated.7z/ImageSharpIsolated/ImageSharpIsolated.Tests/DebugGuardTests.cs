﻿using ImageSharp;

namespace ImageSharpIsolated.Tests;

public class DebugGuardTests
{
    [Fact]
    public void Test1()
    {
        Assert.Throws<ObjectDisposedException>(() => DebugGuard.NotDisposed(true, "Test"));
    }
}
