namespace SharpZipLibIsolated.Isolated
{
    public class ZipEntry
    {
        /// <summary>
        /// Cleans a name making it conform to Zip file conventions.
        /// Devices names ('c:\') and UNC share names ('\\server\share') are removed
        /// and forward slashes ('\') are converted to back slashes ('/').
        /// Names are made relative by trimming leading slashes which is compatible
        /// with the ZIP naming convention.
        /// </summary>
        /// <param name="name">The name to clean</param>
        /// <returns>The 'cleaned' name.</returns>
        /// <remarks>
        /// The <seealso cref="ZipNameTransform">Zip name transform</seealso> class is more flexible.
        /// </remarks>
        public static string CleanName(string name)
        {
            if (name == null)
            {
                return string.Empty;
            }

            if (Path.IsPathRooted(name))
            {
                // NOTE:
                // for UNC names...  \\machine\share\zoom\beet.txt gives \zoom\beet.txt
                name = name.Substring(Path.GetPathRoot(name).Length);
            }

            name = name.Replace(@"\", "/");

            while ((name.Length > 0) && (name[0] == '/'))
            {
                name = name.Remove(0, 1);
            }
            return name;
        }
    }
}