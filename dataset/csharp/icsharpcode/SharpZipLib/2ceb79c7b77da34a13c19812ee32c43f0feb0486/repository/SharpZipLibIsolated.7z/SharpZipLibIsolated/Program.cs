﻿using SharpZipLibIsolated.Isolated;


Console.WriteLine(ZipEntry.CleanName("Test"));
