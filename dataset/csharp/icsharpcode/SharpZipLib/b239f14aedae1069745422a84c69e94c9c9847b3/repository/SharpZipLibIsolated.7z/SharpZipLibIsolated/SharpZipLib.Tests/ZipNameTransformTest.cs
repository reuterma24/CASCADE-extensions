﻿namespace SharpZipLib.Tests;

public class ZipNameTransformTest
{
    [Fact]
    public void Test1()
    {
        ZipNameTransform a = new();
        var x = a.TransformDirectory("auzwdbawda");
        Assert.Empty(x);
    }
}