// Copyright (c) Microsoft. All rights reserved.

using Microsoft.SemanticKernel;
using System.ComponentModel;

namespace SemanticKernel;

public sealed class MathPlugin
{
    /// <summary>
    /// Returns the Sum of two provided numbers.
    /// </summary>
    /// <param name="value">Initial value from which to subtract the specified amount.</param>
    /// <param name="amount">The amount to subtract as a string.</param>
    /// <returns>The resulting subtraction as a string.</returns>
    [KernelFunction, Description("Subtracts an amount from a value")]
    [return: Description("The difference")]
    public int Subtract(
        [Description("The value to subtract")] int value,
        [Description("Amount to subtract")] int amount) =>
        value - amount;
}