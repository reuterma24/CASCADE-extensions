﻿namespace SemanticKernel.Tests;

using SemanticKernel; //to use the MathPlugin

public class SemanticKernelTest
{
    [Fact]
    public void Test1()
    {
        MathPlugin m = new();
        Assert.Equal(5, m.Subtract(10, 5));
    }
}
