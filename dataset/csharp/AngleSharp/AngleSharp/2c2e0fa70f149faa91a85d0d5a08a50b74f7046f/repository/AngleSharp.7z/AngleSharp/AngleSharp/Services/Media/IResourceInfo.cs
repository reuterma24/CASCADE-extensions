﻿namespace AngleSharp.Services.Media
{
    /// <summary>
    /// Specifies general resource information.
    /// </summary>
    public interface IResourceInfo
    {
    }
}
