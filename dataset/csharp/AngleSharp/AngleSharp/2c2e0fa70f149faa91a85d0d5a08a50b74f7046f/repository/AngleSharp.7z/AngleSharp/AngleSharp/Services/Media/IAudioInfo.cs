﻿namespace AngleSharp.Services.Media
{
    /// <summary>
    /// Contains information about a sound file.
    /// </summary>
    public interface IAudioInfo : IMediaInfo
    {
    }
}
