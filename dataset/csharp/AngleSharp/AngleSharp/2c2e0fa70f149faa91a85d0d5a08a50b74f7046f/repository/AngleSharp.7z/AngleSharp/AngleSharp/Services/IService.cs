﻿namespace AngleSharp.Services
{
    /// <summary>
    /// Defines the basic interface for a common service.
    /// </summary>
    public interface IService
    {
    }
}
