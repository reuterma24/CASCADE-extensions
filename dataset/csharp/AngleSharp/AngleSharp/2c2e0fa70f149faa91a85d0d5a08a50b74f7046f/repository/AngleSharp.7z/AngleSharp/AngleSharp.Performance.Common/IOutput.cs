﻿namespace AngleSharp.Performance
{
    using System;

    public interface IOutput
    {
        void Write(String text);
    }
}
