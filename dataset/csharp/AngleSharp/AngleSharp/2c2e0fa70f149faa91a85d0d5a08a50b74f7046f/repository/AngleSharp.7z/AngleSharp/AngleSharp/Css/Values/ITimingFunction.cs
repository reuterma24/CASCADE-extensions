﻿namespace AngleSharp.Css.Values
{
    /// <summary>
    /// Represents a general timing function.
    /// </summary>
    public interface ITimingFunction
    {
    }
}
