﻿namespace AngleSharp.Performance
{
    using System;

    public interface ITest
    {
        String Name { get; }

        String Source { get; }
    }
}
