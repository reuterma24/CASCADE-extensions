﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AngleSharp.Core.Tests")]
[assembly: AssemblyDescription("Tests for the core of the AngleSharp library.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("AngleVisions")]
[assembly: AssemblyProduct("AngleSharp")]
[assembly: AssemblyCopyright("Copyright ©  2013-2015 Florian Rappl et. al")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("e515df87-a0ef-4165-92c8-6a63f6acd342")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
