---
title: Testing
excerpt: Testing your validation rules
date: 2018-06-26
icon:
  type: fa
  name: fa-graduation-cap
  # name: icon_genius
color: primary
sections:
  - /testing/index
---
