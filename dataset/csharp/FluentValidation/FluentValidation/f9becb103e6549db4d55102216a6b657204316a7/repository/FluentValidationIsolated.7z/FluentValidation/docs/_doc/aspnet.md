---
title: ASP.NET Integration
excerpt: Integration with ASP.NET Core, ASP.NET MVC 5 and ASP.NET WebApi 2
date: 2018-12-1
icon: 
  name: icon_globe
color: green
sections:
  - /aspnet/aspnet
  - /aspnet/core
---