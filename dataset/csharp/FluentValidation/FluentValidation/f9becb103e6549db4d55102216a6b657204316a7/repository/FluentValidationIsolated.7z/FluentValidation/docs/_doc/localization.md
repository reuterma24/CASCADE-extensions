---
title: Localization
excerpt: Translating error messages into other languages
date: 2018-06-26
icon:
  name: icon_document_alt
color: pink
sections:
  - /localization/index
---
