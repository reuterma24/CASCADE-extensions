#region License
// Copyright (c) Jeremy Skinner (http://www.jeremyskinner.co.uk)
// 
// Licensed under the Apache License, Version 2.0 (the "License"); 
// you may not use this file except in compliance with the License. 
// You may obtain a copy of the License at 
// 
// http://www.apache.org/licenses/LICENSE-2.0 
// 
// Unless required by applicable law or agreed to in writing, software 
// distributed under the License is distributed on an "AS IS" BASIS, 
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
// See the License for the specific language governing permissions and 
// limitations under the License.
// 
// The latest version of this file can be found at https://github.com/jeremyskinner/FluentValidation
#endregion

namespace FluentValidation.Tests {
	using System;
	using System.Diagnostics;
	using System.Globalization;
	using System.Linq;
	using System.Threading;
	using Internal;
	using Xunit;
	using Resources;
	using Validators;

	
	public class LocalisedMessagesTester : IDisposable {

		public LocalisedMessagesTester() {
			// ensure the resource provider is reset after any tests that use it.
			ValidatorOptions.ResourceProviderType = null;
		}

        public void Dispose()
        {
            ValidatorOptions.ResourceProviderType = null;
        }

		[Fact]
		public void Correctly_assigns_default_localized_error_message() {
#if CoreCLR
			Assert.True(false, "Not implemented on coreclr");
#else
			var originalCulture = Thread.CurrentThread.CurrentUICulture;
			try {
				var validator = new TestValidator(v => v.RuleFor(x => x.Surname).NotEmpty());

				foreach (var culture in new[] { "en", "de", "fr", "es", "de", "it", "nl", "pl", "pt", "ru", "sv" }) {
					Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture);
					var message = Messages.ResourceManager.GetString("notempty_error");
					var errorMessage = new MessageFormatter().AppendPropertyName("Surname").BuildMessage(message);
					Debug.WriteLine(errorMessage);
					var result = validator.Validate(new Person{Surname = null});
					result.Errors.Single().ErrorMessage.ShouldEqual(errorMessage);
				}
			}
			finally {
				// Always reset the culture.
				Thread.CurrentThread.CurrentUICulture = originalCulture;
			}
#endif
		}

		[Fact]
		public void ResourceProviderType_overrides_default_messagesnote() {
			ValidatorOptions.ResourceProviderType = typeof(MyResources);

			var validator = new TestValidator() {
				v => v.RuleFor(x => x.Surname).NotEmpty()
			};

			var result = validator.Validate(new Person());
			result.Errors.Single().ErrorMessage.ShouldEqual("foo");
		}

		[Fact]
		public void Sets_localised_message_via_expression() {
			var validator = new TestValidator();
			validator.RuleFor(x => x.Surname).NotEmpty().WithLocalizedMessage(() => MyResources.notempty_error);
			var result = validator.Validate(new Person());
			result.Errors.Single().ErrorMessage.ShouldEqual("foo");
		}

		[Fact]
		public void When_using_explicitly_localized_message_does_not_fall_back_to_ResourceProvider() {
			ValidatorOptions.ResourceProviderType = typeof(MyResources);

			var validator = new TestValidator {
				v => v.RuleFor(x => x.Surname).NotEmpty().WithLocalizedMessage(() => MyOverridenResources.notempty_error)
			};

			var results = validator.Validate(new Person());
			results.Errors.Single().ErrorMessage.ShouldEqual("bar");
		}

		[Fact]
		public void Custom_property_validators_should_respect_ResourceProvider() {
			ValidatorOptions.ResourceProviderType = typeof(MyResources);
			var validator = new TestValidator {
				v => v.RuleFor(x => x.Surname).SetValidator(new MyPropertyValidator())
			};

			var results = validator.Validate(new Person());
			results.Errors.Single().ErrorMessage.ShouldEqual("foo");
		}


		[Fact]
		public void When_using_explicitly_localized_message_with_custom_validator_does_not_fall_back_to_ResourceProvider() {
			ValidatorOptions.ResourceProviderType = typeof(MyResources);

			var validator = new TestValidator {
				v => v.RuleFor(x => x.Surname).SetValidator(new MyPropertyValidator())
					.WithLocalizedMessage(() => MyOverridenResources.notempty_error)
			};

			var results = validator.Validate(new Person());
			results.Errors.Single().ErrorMessage.ShouldEqual("bar");
		}

		[Fact]
		public void Can_use_placeholders_with_localized_messages() {
			var validator = new TestValidator {
				v => v.RuleFor(x => x.Surname).NotNull().WithLocalizedMessage(() => TestMessages.PlaceholderMessage, 1)
			};

			var result = validator.Validate(new Person());
			result.Errors.Single().ErrorMessage.ShouldEqual("Test 1");
		}

		[Fact]
		public void Can_use_placeholders_with_localized_messages_using_expressions() {
			var validator = new TestValidator {
				v => v.RuleFor(x => x.Surname).NotNull().WithLocalizedMessage(() => TestMessages.PlaceholderMessage, x => 1)
			};

			var result = validator.Validate(new Person());
			result.Errors.Single().ErrorMessage.ShouldEqual("Test 1");
		}

	    [Fact]
	    public void Setting_global_resource_provider_propogates_to_metadata() {
            ValidatorOptions.ResourceProviderType = typeof(TestMessages);
            var validator = new TestValidator();
            validator.RuleFor(x => x.Forename).NotNull();

            var descriptor = validator.CreateDescriptor();
            var resourceType = descriptor.GetMembersWithValidators().First().First().ErrorMessageSource.ResourceType;

	        Assert.Equal(typeof (TestMessages), resourceType);

	    }

        [Fact]
        public void Not_Setting_global_resource_provider_uses_default_messages_in_metadata()
        {
            var validator = new TestValidator();
            validator.RuleFor(x => x.Forename).NotNull();

            var descriptor = validator.CreateDescriptor();
            var resourceType = descriptor.GetMembersWithValidators().First().First().ErrorMessageSource.ResourceType;

            Assert.Equal(typeof(Messages), resourceType);

        }

		private class MyResources {
			public static string notempty_error {
				get { return "foo"; }
			}
		}

		private class MyOverridenResources {
			public static string notempty_error {
				get { return "bar"; }
			}
		}

		private class MyPropertyValidator : PropertyValidator {
			public MyPropertyValidator() : base(() => MyOverridenResources.notempty_error) {
				
			}

			protected override bool IsValid(PropertyValidatorContext context) {
				return false;
			}
		}
	}
}